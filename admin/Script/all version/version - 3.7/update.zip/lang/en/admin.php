<?php
 return array (
  'Theme color' => 'Theme color',
  'Primary color' => 'Primary color',
  'Secondary color' => 'Secondary color',
  'Administrator Status' => 'Administrator Status',
  'Awaiting for approval' => 'Awaiting for approval',
  'Awaiting' => 'Awaiting',
);
 ?>
